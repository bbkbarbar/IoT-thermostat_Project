void sendDataToKaaIoT(short retryCount, String ps, float temperature , float humidity, float tempSet , float overheating , String heating){

    String phaseStatusToSend = "";
    if(ps == "1"){
      phaseStatusToSend = "1";
    }else{
      phaseStatusToSend = "10"; 
    }

    String heatingToSend = "";
    if(heating == String(HEATING)){
      heatingToSend = "12";
    }else{
      heatingToSend = "0"; 
    }

    float ct = tempSet + overheating;
  
    String postData = 
                "{\n";
    postData += "\t\"temperature\": " + String(temperature) + ",\n";
    postData += "\t\"tempSet\": "     + String(tempSet) + ",\n";
    postData += "\t\"calculatedTarget\": " + String(ct) + ",\n";
    postData += "\t\"humidity\": "    + String(humidity) + ",\n";
    postData += "\t\"overheating\": " + String(overheating) + ",\n";

    // NOT IMPORTANT
    postData += "\t\"RSSI-" + String(SHORT_NAME) + "\": " + String(WiFi.RSSI()) + ",\n";
    
    postData += "\t\"phaseStatus\": " + phaseStatusToSend + ",\n";
    postData += "\t\"heating\": "     + heatingToSend + "\n";
    postData += "}";

    Serial.println("PostData:\n" + postData);
    
    // new
    
    String url = String(KAA_POST_PATH);
    //String url = String(MOCK_SERVICE_PATH);

    //http.begin(client, url.c_str());  //Specify request destination
    WiFiClient wfc;
    http.begin(wfc, url);  //Specify request destination

    //http.addHeader("Content-Type", "text/plain");
    //http.addHeader("Content-Type", "application/x-www-form-urlencoded");
    http.addHeader("Content-Type", "application/json");
    int httpCode = http.POST(postData);                                  //Send the request
    Serial.println("POST request sent: " + String(httpCode) + " " + url);

    //Close connection
    http.end();   //Close connection

    // TODO check http code if needed
    if( (httpCode != 200) && (retryCount > 0) ){
      sendDataToKaaIoT( (retryCount-1), ps, temperature, humidity, tempSet, overheating, heating);
    }

}